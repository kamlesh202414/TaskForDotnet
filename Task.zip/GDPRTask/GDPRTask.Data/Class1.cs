﻿namespace GDPRTask.Data
{
    public class Class1
    {

    }
}
