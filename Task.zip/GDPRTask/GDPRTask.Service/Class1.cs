﻿namespace GDPRTask.Service
{
    public class Class1
    {

    }
}
