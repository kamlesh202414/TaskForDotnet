import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterOutlet } from '@angular/router';
import { CommonModule } from '@angular/common';  // Import CommonModule
import { User } from '../model/userModel'; // Ensure this path is correct

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FormsModule, HttpClientModule, CommonModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  apiUrl = 'https://localhost:7091/api/User';
  users: User[] = [];
  selectedUser: User = {
    name: '', email: '', gdprConsent: false,
    id: ''
  }; // Initialize selectedUser

  constructor(private http: HttpClient) {}

  ngOnInit(): void {
    this.fetchUsers(); // Fetch users on component initialization
  }

  fetchUsers() {
    this.http.get<User[]>(this.apiUrl).subscribe(
      response => {
        this.users = response;
      },
      error => {
        console.error('Error fetching users:', error);
      }
    );
  }

  onSubmit() {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const userData = { ...this.selectedUser }; // Clone the selectedUser

    // Generate a unique random integer ID for new users
    if (!this.selectedUser.id) {
      userData.id = this.generateId(); // Generate ID if not existing
    }

    const userJson = JSON.stringify(userData);

    if (this.selectedUser.id) {
      // Update existing user
      this.http.put(`${this.apiUrl}/${this.selectedUser.id}`, userJson, { headers })
        .subscribe(
          response => {
            console.log('User updated successfully:', response);
            this.fetchUsers(); // Refresh the user list
            this.resetForm();
            alert('User updated successfully!'); // Success message for update
          },
          error => {
            console.error('Error updating user:', error);
            alert('Failed to update user. Please try again.');
          }
        );
    } else {
      // Create new user
      this.http.post(this.apiUrl, userJson, { headers })
        .subscribe(
          response => {
            console.log('User created successfully:', response);
            this.fetchUsers(); // Refresh the user list
            this.resetForm();
            alert('User created successfully!'); // Success message for creation
          },
          error => {
            console.error('Error creating user:', error);
            alert('Failed to create user. Please try again.');
          }
        );
    }
  }

  editUser(user: User) {
    this.selectedUser = { ...user }; // Copy user details to selectedUser for editing
  }

  deleteUser(id: string) {
    if (confirm('Are you sure you want to delete this user?')) { // Confirmation before deletion
      this.http.delete(`${this.apiUrl}/${id}`).subscribe(
        response => {
          console.log('User deleted successfully:', response);
          this.fetchUsers(); // Refresh the user list
          alert('User deleted successfully!'); // Success message for deletion
        },
        error => {
          console.error('Error deleting user:', error);
          alert('Failed to delete user. Please try again.');
        }
      );
    }
  }

  resetForm() {
    this.selectedUser = { id: '', name: '', email: '', gdprConsent: false }; // Reset form after submission
  }

  // Method to generate a unique random integer ID as a string
  private generateId(): string {
    const min = 1000; // Minimum value for ID
    const max = 9999; // Maximum value for ID
    const randomId = Math.floor(Math.random() * (max - min + 1)) + min; // Generate a random integer between min and max
    return randomId.toString(); // Return ID as a string
  }
}
